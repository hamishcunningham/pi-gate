%close
clf

%colors={'blue', 'green', 'red', 'flashing'};
colors = [ 0 0 1 ; 0 0.5 0; 1 0 0; 0.5 0 0];

d = csvread('log.csv');
split = find(diff(d(:,1)) > 10);
if length(split) == 0
	split = 0;
end


subplot(2, 1, 1)
if split == 0
	z = plot(d(:,1), d(:,3), 'Color', [0 0.8 0.8]);
	set(z, 'linewidth', 2);
else
	z = plot(d(1:split,1), d(1:split,3), 'Color', [0 0.8 0.8]);
	set(z, 'linewidth', 2);
	hold on
	z = plot(d(split+1:end,1), d(split+1:end,3), 'Color', [0 0.8 0.8]);
	set(z, 'linewidth', 2);
	hold off
end
% plot horizontal lines for colors

%xl = xlim;
xl(1) = d(1);
hours = ceil((d(end,1)-d(1,1))/60/60);
xl(2) = hours*60*60+d(2);
xlim(xl)
xtick = [0:2:hours]*60*60;
xticklabel = cell(size(xtick));
for i=1:length(xtick)
%	xticklabel{i} = sprintf("%i hours", i-1);
	xticklabel{i} = sprintf("%i", (i-1)*2);
end
set(gca, 'XTick', xtick+d(1));
set(gca, 'XTickLabel', xticklabel);
xlabel('Time (hours)')
ylabel('mV')

%  Maximum voltage: 11200 mV
%  Good voltage: 9800 mV
%  Low voltage: 8800 mV
%  Critical voltage: 8000 mV

%levels = [11200 9800 8800 8000];
levels = [11200 10000 8800 8000];
for i=1:4
	z = line(xl, ones(1,2)*levels(i));
	set(z, 'linewidth', 2);
	set(z, 'linestyle', '--');
	set(z, 'Color', colors(i, :));
end



subplot(2, 1, 2)

for i=1:4
	if sum(d(:,2)==i) > 0
		t(1) = find(d(:,2)==i,1);
		t(2) = find(d(:,2)==i,1, 'last');
		if split ~= 0 && t(1) < split && t(2) > split
			doloop = 2;
		else
			doloop = 1;
		end
		for j=1:doloop
			t(1) = find(d(:,2)==i,1);
			t(2) = find(d(:,2)==i,1, 'last');
			if doloop == 2
				if j == 1
					t(2) = split;
				else
					t(1) = split+1;
				end
			end

			duration = d(t(2),1) - d(t(1),1) + 5;

			z = rectangle('Position', [d(t(1),1) 0.3, duration, 0.3]);
			set(z, 'FaceColor', colors(i, :));
			set(z, 'linewidth', 2);

			if mod(i,2) == 1
				ypos = 0.65;
			else
				ypos = 0.25;
			end
			hours = floor(duration/60/60);
			minutes = floor(duration/60-hours*60);
			seconds = duration - minutes*60 - hours*60*60;
			z = text(duration/2 + d(t(1),1), ypos, sprintf("%i:%02i:%02i", hours, minutes, seconds));
			set(z, 'HorizontalAlignment', 'center')
			set(z, 'Color', colors(i, :));
		end
	end
end

yel = d(find(d(:,4), 1), 1);
if length(yel) ~= 0
%	yel = d(3000);
	duration = d(end,1)-yel+5;
	z = rectangle('Position', [yel 0.3, duration, 0.1]);
	set(z, 'FaceColor', [1 1 0]);
	set(z, 'linewidth', 2);
	hours = floor(duration/60/60);
	minutes = floor(duration/60-hours*60);
	seconds = duration - minutes*60 - hours*60*60;
	z = text(yel-(xl(2)-xl(1))*0.01, 0.35, sprintf("%i:%02i:%02i", hours, minutes, seconds));
	set(z, 'HorizontalAlignment', 'right')
	set(z, 'Color', [1 1 0])
end

if split ~= 0
	endtext = d(split,1)+(xl(2)-xl(1))*0.01;
	duration = d(split,1)-d(1,1);
	hours = floor(duration/60/60);
	minutes = floor(duration/60-hours*60);
	seconds = duration - minutes*60 - hours*60*60;
	z = text(endtext, 0.45, sprintf("%i:%02i:%02i", hours, minutes, seconds));
	set(z, 'rotation', 90)
	set(z, 'HorizontalAlignment', 'center')
	set(z, 'VerticalAlignment', 'top')

	duration = d(split+1,1)-d(split,1);
	hours = floor(duration/60/60);
	minutes = floor(duration/60-hours*60);
	seconds = duration - minutes*60 - hours*60*60;
	z = text(mean(d(split:split+1)), 0.45, sprintf("zzzZZZzzz\n(%i:%02i:%02i)", hours, minutes, seconds));
	set(z, 'HorizontalAlignment', 'center')

end

endtext = d(end,1)+(xl(2)-xl(1))*0.01;
if split == 0
	duration = d(end,1)-d(1,1);
else
	duration = d(end,1)-d(1,1)-d(split+1,1)+d(split,1);
end
hours = floor(duration/60/60);
minutes = floor(duration/60-hours*60);
seconds = duration - minutes*60 - hours*60*60;
%endtext = d(end,1)+(xl(2)-xl(1))*0.01;
z = text(endtext, 0.45, sprintf("%i:%02i:%02i", hours, minutes, seconds));
set(z, 'rotation', 90)
set(z, 'HorizontalAlignment', 'center')
set(z, 'VerticalAlignment', 'top')

ylabel('LED Color')
ylim([0.15 0.75]) 
xlim(xl)
set(gca, 'YTick', [])
set(gca, 'XTick', xtick+d(1));
set(gca, 'XTickLabel', xticklabel);
xlabel('Time (hours)')

%return

FN = findall(gcf, '-property', 'FontName');
set(FN, 'FontName', '/usr/share/fonts/dejavu/DejaVuSerifCondensed.ttf');
FS = findall(gcf, '-property', 'FontSize');
set(FS, 'FontSize', 6);
%print('t.eps', '-deps2', '-color')
%print("test.png", '-dpng', '-color', '-S1280,720')
%print("test.png", '-dpng', '-color', '-S1024,600')
print("test.png", '-dpng', '-color', '-S500,360')
