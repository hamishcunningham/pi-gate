rm *.png; for l in mopi*; do php convertlog.php $l; octave voltageplot.m; mv test.png $l.png; done
