<?php

//$file = explode("\n", file_get_contents('voltage.log.2'));
if (file_exists($_SERVER['argv'][1])) {
	$file = explode("\n", file_get_contents($_SERVER['argv'][1]));
}
else {
	file_put_contents("php://stderr", "error reading: ".$_SERVER['argv'][1]."\n");
	exit(1);
}

$out = array();
$entry = array();

foreach ($file as $line) {

	if (strpos($line, 'ut:') === 0) {
		if (!empty($entry) && count($entry) == 3) { // count to catch and ignore the error lines...
			if ($lows == 2)
				$entry[] = 1;
			else
				$entry[] = 0;
			$out[] = implode(",", $entry);
		}

		$time = substr($line, 3);

		$entry = array();
		$entry[] = $time;
		$lows = 0;
	}

	if (strpos($line, 'led') > 0) {
		if (strpos($line, 'blue') > 0)
			$entry[] = 1;
		elseif (strpos($line, 'green') > 0)
			$entry[] = 2;
		elseif (strpos($line, 'low') > 0) // red
			$entry[] = 3;
		elseif (strpos($line, 'flashing') > 0) // red
			$entry[] = 4;
	}

	if (strpos($line, 'Current') === 0) {
		$entry[] = substr($line, 24);
	}

	if (strpos($line, 'low/not') > 0) {
		$lows++;
	}
}


if ($lows == 2)
	$entry[] = 1;
else
	$entry[] = 0;
$out[] = implode(",", $entry);
if (empty($_SERVER['argv'][2])) {
	file_put_contents("log.csv", implode("\n", $out));
	print "written to log.csv, ";
}
else {
	file_put_contents($_SERVER['argv'][2], implode("\n", $out));
	print "written to ".$_SERVER['argv'][2].", ";
}
print "conversion OK\n";

?>
